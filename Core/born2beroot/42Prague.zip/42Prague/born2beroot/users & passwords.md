**ENCRYPTION PASSPHRASE:** Sup3rStr0ng

| **user name**    | **password** |
| :--------------: | :----------: |
| root             | ThisIsStr0ng     |
| lhaken           | ThisIsStr0nger     |