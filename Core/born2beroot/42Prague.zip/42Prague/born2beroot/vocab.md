# PROJECT VOCABULARY 📖
***
This page explains all of the importat, non-trivial vocabulary used in this project manual.
***
> [!tip]- VM - Virtual Machine
> 
> it's a software that simulates computer hardware

> [!tip]- LVM - Logical Volume Management
> 
>  a disk space manager that allows user to separate the disk into partitions
^766f15

> [!tip]- SSH - Secure Shell
> 
> secured communication protocol and a program that allows for a secure communication between 2 computers over a command line
^039c1a

> [!tip]- UFW - Uncomplicated Firewall
>
> a command line program that is designed for managing a netfilter firewall with the use of iptables
^7c43c8

> [!tip]- Cron
> 
> a background process manager, that controls when processes will be executed (time, day etc.)

^264861

